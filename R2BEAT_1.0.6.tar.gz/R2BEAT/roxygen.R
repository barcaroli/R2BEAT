roxygen2::roxygenize(package.dir = "D:\\Google Drive\\\\Sampling\\R2BEAT\\R2BEAT_1.0.6\\", roclets = NULL, load_code = NULL, clean = FALSE)


# roxygen2::roxygenize(package.dir = "C:\\Users\\UTENTE\\Google Drive\\Sampling\\R2BEAT\\R2BEAT_work\\", roclets = NULL, load_code = NULL, clean = FALSE)

